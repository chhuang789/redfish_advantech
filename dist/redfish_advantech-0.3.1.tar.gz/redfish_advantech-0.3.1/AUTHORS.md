# Original Contribution:

- [C.H. Huang](https://github.com/chhuang789/redfish_advantech) - Advantech - CIoT TSE
